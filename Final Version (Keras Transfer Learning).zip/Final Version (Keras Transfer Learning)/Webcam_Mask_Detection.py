#imports
import cv2
import os
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
from tensorflow.keras.preprocessing.image import img_to_array
from tensorflow.keras.models import load_model
import time
import imutils
from imutils.video import VideoStream
import numpy as np

detect = None 
def mask_detection(frame, faceDet, maskDet, threshold):
    
    # use frame dimensions to create a blob
	global detect 
	(height, width) = frame.shape[:2]
	bfi = cv2.dnn.blobFromImage(frame, 1.0, (300, 300),(104.0, 177.0, 123.0))

    # obtaining face detections by passing blob through network
	faceDet.setInput(bfi)
	detect = faceDet.forward()

    # initialising list of face along with their locations
	ROI = []
	loc = []
	pred = []
    
	# looping over detections
	for i in range(0, detect.shape[2]):
        
		# extract the confidence scores
		conf = detect[0, 0, i, 2]

        # exluding weak any detections
        # this is done by making the confidence score is larger than the threshold
		if conf > threshold:

            #computing x and y coordinates for the bounding boxes of objects
			bbox = detect[0, 0, i, 3:7] * np.array([width, height, width, height])
			(startX, startY, endX, endY) = bbox.astype("int")

            # making sure the bounding boxes are within the frame dimensions
			(startX, startY) = (max(0, startX), max(0, startY))
			(endX, endY) = (min(width - 1, endX), min(height - 1, endY))

            # face ROI extracted and preprocessed
			ROI = frame[startY:endY, startX:endX]
			ROI = cv2.cvtColor(ROI, cv2.COLOR_BGR2RGB)
			ROI = cv2.resize(ROI, (224, 224))
			ROI = img_to_array(ROI)
			ROI = preprocess_input(ROI)
			ROI = np.expand_dims(ROI, axis=0)
            
            #append faces and bounding boxes to their lists
			loc.append((startX, startY, endX, endY))
			#print(maskDet.predict(face)[0].tolist())
			pred.append(maskDet.predict(ROI)[0].tolist())
	return (loc, pred)

# file paths to models and settings
MASK_MODEL=os.getcwd()+"\\model\\Exported-Model.h5"
FACE_MODEL=os.getcwd()+"\\Face_Detection" 
THRESHOLD = 0.5

# loading FACE detection model
prototxtPath = os.path.sep.join([FACE_MODEL, "deploy.prototxt"])
weightsPath = os.path.sep.join([FACE_MODEL,"res10_300x300_ssd_iter_140000.caffemodel"])
faceDet = cv2.dnn.readNet(prototxtPath, weightsPath)

# loading MASK detection model
maskDet = load_model(MASK_MODEL)

# initialising the live camera stream
print("Opening video stream...")
cap = VideoStream(0).start()
time.sleep(2.0)

#looping frames over video stream
while True:
        
    # take frame and resize to 350 pixels max (width)
	frame = cap.read()
	frame = imutils.resize(frame, width=350)
	org_frame = frame.copy()
	(loc, pred) = mask_detection(frame, faceDet, maskDet, THRESHOLD)

    #looping over locations of detected faces
	for (bbox, pred) in zip(loc, pred):
                  
		# predictions and bounding boxes
		(startX, startY, endX, endY) = bbox
		(mask, no_mask) = pred
        
        # setting class labels and color for each class 
		text = "Mask" if mask > no_mask else "No Mask"
		color = (0, 255, 0) if text == "Mask" else (0, 0, 255)

		# pair confidence score with the text
		text = "{}: {:.0f}%".format(text, max(mask, no_mask) * 100)
        
        #bounding box and text display settings
        #text
		cv2.putText(org_frame, text, (startX, startY - 10),cv2.FONT_HERSHEY_SIMPLEX, 0.65, color, 2) 
        #bounding box
		cv2.rectangle(org_frame, (startX, startY), (endX, endY), color, 2)  

	cv2.addWeighted(frame, 0.5, org_frame, 1, 0.5, frame)

	# show the output frame
	frame= cv2.resize(frame,(1280,720))
	cv2.imshow("Face Mask Detection", frame)
	keyEnd = cv2.waitKey(1) & 0xFF
    
	# when key "x" is pressed, the loop will break and the application will shut down
	if keyEnd == ord("x"):
    		break 

#application shutting down
cv2.destroyAllWindows()
cap.stop()

    
