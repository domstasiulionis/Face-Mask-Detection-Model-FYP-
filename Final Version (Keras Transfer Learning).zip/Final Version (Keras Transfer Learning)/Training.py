#imports
import numpy as np
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input
from tensorflow.keras.layers import Dropout
from tensorflow.keras.layers import Flatten
from tensorflow.keras.layers import Dense
from tensorflow.keras.layers import AveragePooling2D
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
from tensorflow.keras.preprocessing.image import img_to_array
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.preprocessing.image import load_img
from sklearn.model_selection import KFold
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelBinarizer
from imutils import paths
import matplotlib.pyplot as plt
from datetime import datetime

#paths
img_dataset="Images" # dataset
output_model="NewModel" # name of saved model
plot_path="Graph" # name of saved graph
num_folds = 5

#state number of epochs, batch size and learning rate for training
EPOCHS = 10 #epochs
BATCH = 18 #batch size
LR = 1e-4 #learning rate

# initialize the list of data from the image directories
img_paths = list(paths.list_images(img_dataset))
img_paths = [img_path.replace("\\","//",-1) for img_path in img_paths]

data = []
labels = []

# loop over the image paths
for img_path in img_paths:
    
	# extract the class label
	label = img_path.split("//")[-2]

	# preprocessing loaded iamges
	img = load_img(img_path, target_size=(224, 224)) #change image size
	img = img_to_array(img) 
	img = preprocess_input(img)

	# update the labels and images 
	data.append(img)
	labels.append(label)

# converting data and label into numpy arrays
data = np.array(data, dtype="float32")
labels = np.array(labels)

# one hot encoding on the labels
lab_bin= LabelBinarizer()
labels = lab_bin.fit_transform(labels)
labels = to_categorical(labels)

# splitting data into train and test
(trainX, testX, trainY, testY) = train_test_split(data, labels,
	 stratify=labels, random_state=42)

# generate input and target varibales for
inputs = np.concatenate((trainX, testX), axis=0)
targets = np.concatenate((trainY, testY), axis=0)

# fold metrics variable declaration
loss_per_fold = []
accuracy_per_fold = []

#use image data generator to create augmented images for training
augmnetedimg = ImageDataGenerator(
	zoom_range=0.12,
    rotation_range=15,
    shear_range=0.15,
	horizontal_flip=True,
	width_shift_range=0.2,
	height_shift_range=0.2,
	fill_mode="nearest")

# import the MobileNetV2 model excluding its head FC layer
pretrainedmod = MobileNetV2(weights="imagenet",
                            include_top=False, 
                            input_tensor=Input(shape=(224, 224, 3))) #224x224 RGB input

# Define the K-fold Cross Validator
kfoldval = KFold(n_splits=num_folds, shuffle=True)

#start time
start = datetime.now()

# K-fold Cross Validation model evaluation
fold_num = 1
for train, test in kfoldval.split(inputs, targets):

    # create the head of  the model that will be joined with the pretrained model
    FC = pretrainedmod.output
    FC = AveragePooling2D(pool_size=(7, 7))(FC)
    FC = Flatten(name="flatten")(FC)
    FC = Dense(128, activation="relu")(FC)
    FC = Dropout(0.5)(FC)
    FC = Dense(2, activation="sigmoid")(FC)

    # insert the new head FC into the pretrained model
    # it has now become the actual model that will be trained
    newmodel = Model(inputs=pretrainedmod.input, outputs=FC)

    # freeze the layers in the pretrained to prevent them from being updated during training
    for layer in pretrainedmod.layers:
	    layer.trainable = False

    # compile the new model
    optimizer = Adam(lr=LR, decay=LR / EPOCHS)
    newmodel.compile(loss="binary_crossentropy", optimizer=optimizer,
	metrics=["accuracy"])

    # print the folder number that is being trained
    print('------------------------------------------------------------------')
    print(f'Training for fold: {fold_num} ...')

    # training process inititated
    # training the trainable params from the head FC
    # frozen layers will not be altered
    mh = newmodel.fit(
	augmnetedimg.flow(trainX, trainY, batch_size=BATCH),
	steps_per_epoch=len(trainX) // BATCH,
	validation_data=(testX, testY),
	validation_steps=len(testX) // BATCH,
	epochs=EPOCHS)
    
    # generate mertrics data for folds
    scores = newmodel.evaluate(inputs[test], targets[test], verbose=0)
    print(f'Score for fold {fold_num}: {newmodel.metrics_names[0]} of {scores[0]}; {newmodel.metrics_names[1]} of {scores[1]*100}%')
    accuracy_per_fold.append(scores[1] * 100)
    loss_per_fold.append(scores[0])

    # increment the fold number
    fold_num = fold_num + 1

# Average of fold scores
print('------------------------------------------------------------------')
print('Score per fold')

for i in range(0, len(accuracy_per_fold)):
  print('------------------------------------------------------------------')
  print(f'> Fold {i+1} - Loss: {loss_per_fold[i]} - Accuracy: {accuracy_per_fold[i]}%')
print('------------------------------------------------------------------')
print('Average scores for all folds:')
print(f'> Accuracy: {np.mean(accuracy_per_fold)} (+- {np.std(accuracy_per_fold)})')
print(f'> Loss: {np.mean(loss_per_fold)}')
print('------------------------------------------------------------------')

# view the model achitecture
newmodel.summary()

# save model as .h5 file to disk
print("Saved model to path: %s"%(output_model+".h5"))
newmodel.save(output_model+".h5")

#print how long the process has taken
duration = datetime.now() - start
print("Training completed in time: ", duration)

# generate and plot graphs for accuracy and loss
E = EPOCHS
plt.style.use("ggplot")
plt.figure()
plt.plot(np.arange(0, E), mh.history["loss"], label="train_loss")
plt.plot(np.arange(0, E), mh.history["val_loss"], label="val_loss")
plt.plot(np.arange(0, E), mh.history["accuracy"], label="train_accuracy")
plt.plot(np.arange(0, E), mh.history["val_accuracy"], label="val_accuracy")
plt.title("Training Loss / Accuracy")
plt.xlabel("Epoch")
plt.ylabel("Loss/Accuracy")
plt.legend(loc="lower left")
plt.savefig(plot_path)