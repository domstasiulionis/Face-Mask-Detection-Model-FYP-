#imports
import tensorflow as tf
import cv2
import argparse
import numpy as np
from PIL import Image
import warnings

# file paths
argparse = argparse.ArgumentParser()
argparse.add_argument('--model', default='Inference_graph')
argparse.add_argument('--labels', default='label_map.pbtxt')
argparse.add_argument('--threshold', default=0.5)
args = argparse.parse_args()

# GPU dynamic memory allocation
gpus = tf.config.experimental.list_physical_devices('GPU')
for gpu in gpus:
    tf.config.experimental.set_memory_growth(gpu, True)

# path to models directory
model_dir_path = args.model
# path to the label map
label_path = args.labels
# minimum threshold
minimum_conf = float(args.threshold)

# loading dependencies
from object_detection.utils import visualization_utils as viz_utils
from object_detection.utils import label_map_util

# path to saved model
PATH_TO_SAVED_MODEL = model_dir_path + "/saved_model"

# Load saved model and build the detection function
detectfunc = tf.saved_model.load(PATH_TO_SAVED_MODEL)

# loading label map (needed for plotting labels)
cat_index = label_map_util.create_category_index_from_labelmap(label_path, use_display_name=True)

# suppressing warnings
warnings.filterwarnings('ignore')

# convert input image to numpy array of shape: [y, x, 3].
def img_to_numpy(path):
    return np.array(Image.open(path))

# initializing the webcam
videostream = cv2.VideoCapture(0)

# webcam stream settings
cap = videostream.set(3,1920)
cap = videostream.set(4,1080)

while True:

    # take frame then convert the dimensions of frame to shape: [1, None, None, 3]
    # a single-column array - containing the RBG value
    cap, frame = videostream.read()
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
    frame_expansion = np.expand_dims(rgb_frame, axis=0)
    imH, imW, _ = frame.shape

    # converting input to tensors
    tensor_input = tf.convert_to_tensor(frame)
    tensor_input = tensor_input[tf.newaxis, ...]
    det = detectfunc(tensor_input)

    # converting to numpy array then taking index 0 to remove batch dimension
    num_detections = int(det.pop('num_detections'))
    det = {key: value[0, :num_detections].numpy() for key, value in det.items()}
    det['num_detections'] = num_detections

    # detection_classes should be ints.
    det['detection_classes'] = det['detection_classes'].astype(np.int64)

    # setting minimum threshold for detections
    det['detection_classes'] = det['detection_classes'].astype(np.int64)
    obj_classes = det['detection_classes']
    bbox = det['detection_boxes']
    score = det['detection_scores']

    for i in range(len(score)):
        if ((score[i] > minimum_conf)):

            # using coordinates, draw bounding box
            # ensure returned bounding box is within the dimensions of the image

            # minimum y axis
            ymin = int(max(1, (bbox[i][0] * imH)))
            # minimum x axis
            xmin = int(max(1, (bbox[i][1] * imW)))
            # maximum y axis
            ymax = int(min(imH, (bbox[i][2] * imH)))
            # maximum x axis
            xmax = int(min(imW, (bbox[i][3] * imW)))

            # drawing bounding box
            cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), (10, 255, 0), 2)

            # finding name of object from the labels array using the index of the class
            obj_name = cat_index[int(obj_classes[i])]['name']

            # confidence score
            label_name = '%s: %d%%' % (obj_name, int(score[i] * 100))

            # font size and family
            label_size, baseLine = cv2.getTextSize(label_name, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)

            # expand margin for labels position - to avoid clashing with bounding box
            ymin_label = max(ymin, label_size[1] + 10)

            # drawing box around the label
            cv2.rectangle(frame, (xmin, ymin_label - label_size[1] - 10),
                          (xmin + label_size[0], ymin_label + baseLine - 10), (255, 255, 255), cv2.FILLED)

            # drawing the label text
            cv2.putText(frame, label_name, (xmin, ymin_label - 7), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), 2)

    # title of window
    cv2.imshow('Face Mask Detection', frame)

    # when key "x" is pressed, window will shut down / loop will break
    if cv2.waitKey(1) == ord('x'):
        break

# shuts down all windows and exit
cv2.destroyAllWindows()
